// let str = "hello how are you";
// console.log(str.split(" ").map(data => data.slice(0,1).toUpperCase()+ data.slice(1)).join(" "))
// console.log(str.split(" ").map(data => data.slice(0,-1) + data.slice(-1).toUpperCase()).join(" "))
// console.log(str.split(" ").map(data =>data.slice(0,1).toUpperCase()+ data.slice(1,-1) + data.slice(-1).toUpperCase()).join(" "))
// Hello How Are You
// hellO hoW arE yoU
// HellO HoW ArE YoU




//rotate arr  output =[ 4, 5, 1, 2, 3 ]
// let arr = [1,2,3,4,5]
// let k = 2;
// function rotate(k){
// k = k%23
// let len = arr.length    

//    function reverse(arr,start,end){
//        while(start<end){
//            [arr[start],arr[end]] = [arr[end],arr[start]]
//            start++;
//            end--;
//        }
//    console.log(arr)
//    }
//    reverse(arr,0,len-1)
//    reverse(arr,0,k-1)
//    reverse(arr,k,len-1)
   
//    return arr
// }
// rotate(k)



// Majority Element (output 2)
// let arr =[3,2,3,2,2]
// let obj ={}
// function test(arr){
//     for(let i=0; i<arr.length; i++){
//         if(obj[arr[i]]){
//             obj[arr[i]] += 1
//         }
//         else{
//             obj[arr[i]]= 1
//         }
//         if(obj[arr[i]]>arr.length/2){
//             return arr[i]
//         }
//     }
// }
// console.log(test(arr))



// max and min (4,-5)
// let arr = [-2,1,-3,4,-1,2,1,-5,4]
// let max = arr[0]
// let min = arr[0]
// for(let i=1; i<arr.length; i++){
//     if(arr[i]>max) max = arr[i]
//     else if(arr[i]<min) min= arr[i]
// }
// console.log(max,min)


// Maximum subarray sum + print subarray
// let arr = [-2,1,-3,4,-1,2,1,-5,4]
// let curSum = arr[0];
// let maxSum = arr[0];
// let temp = 0;
// let start = 0;
// let end = 0;

// for(let i=1; i<arr.length; i++){
//     if(arr[i]>arr[i]+curSum){
//         curSum = arr[i]
//         temp = i
//     }else{
//         curSum += arr[i]
//     }
//     if(maxSum<curSum){
//         maxSum = curSum;
//         start = temp;
//         end = i
//     }
    
// }

// console.log(maxSum)
// console.log(arr.slice(start,end+1))




//op([1,2,3])
// let arr = [1,1,2,2,3]
// let output =  new Set(arr)
// console.log([...output])

// let arr = [1,1,2,2,3]
// let output = []
// for(let i=0; i<arr.length; i++){
//     let flag = output.includes(arr[i])
//     if(!flag){
//         output.push(arr[i])
//     }
    
// }

// console.log(output)


// let arr = [1,1,2,2,3]
// let j =0

// for(let i=1; i<arr.length; i++){
//     if(arr[i]!==arr[j]){
//         j++
//         arr[j]=arr[i]
//     }
// }

// console.log(arr.slice(0,j+1))



//op(3a1b3a2c1d1e2s)
// let str= "AaABaaaccdess".toLowerCase();
// let output =""
// let count = 1
// let temp = str[1]

// for(let i=1; i<str.length; i++){
//     if(str[i]==temp){
//         count += 1 
//     }else{
//         output += count + temp
//         temp = str[i]
//         count=1
//     }
// }

// console.log(output + count + temp)


//op slidingwindow (13)
// let arr = [2,3,4,2,1,4,0,6,0,3,4,0,2,5];
// let limit = 4;
// let windowSum = 0;
// let maxSum = 0;
// function test(arr,limit){
    
//     for(let i=0; i<limit; i++){
//         windowSum += arr[i]
//     }
    
//     maxSum = windowSum;
    
//     for(let j=limit; j<arr.length; j++){
//         windowSum += arr[j] -arr[j-limit]
        
//         maxSum = Math.max(windowSum,maxSum)
//     }
    
//     return maxSum
    
// }

// console.log(test(arr,limit))


// let arr = [23,24,53,67,78,12,2,4,5]
// console.log(arr.reverse())
// console.log(arr.sort((a,b)=> b-a))


// let str = "check the data"
// console.log(str.split("").reverse().join(" "))



// let arr = [23,24,53,67,78,12,2,4,5]
// let a  = arr.slice(-2)
// console.log(a)




// let arr = [23,24,53,67,78,12,2,4,5]
// let arr1 = [23,24,53,67,78,12,2,4,5]
// arr.splice(0,7,111)
// let a = arr1.slice(0,4)
// console.log(arr)
// console.log(a)
// console.log(arr1)


// let str = "test"
// console.log([...str].reverse().join(""))



// const arr = [1, 2, 3," ",{},[],"",undefined,null,0];
// arr.forEach((item) => {
//   console.log(item);
// })


// (function(){
//    console.log("hello") 
// })()




// op(1/ 2 /3 /1)
// function Parent(){
//     let count = 0;
//     return function (){
//         count++
//         return count;
//     }
// }

// let a = Parent()
// console.log(a())
// console.log(a())
// console.log(a())

// let a1 = Parent()
// console.log(a1())



// //max sum of array
// let arr = [-2,1,-3,4,-1,2,1,-5,4];
// let curSum = arr[0]
// let maxSum  = arr[0]
// let temp = 0;
// let start = 0;

// for(let i=1; i<arr.length; i++){
    
//     if(arr[i]>curSum+arr[i]){
//         curSum =arr[i]
//          temp = i
//     }else{
//          curSum +=arr[i]
//     }
//     if(maxSum<curSum){
//      maxSum = curSum;
//      start = temp;
//      end = i; 
//     }
    
// }

// console.log(maxSum)
// console.log(arr.slice(start,end+1))



// ///max sum of array
// let arr = [2,5,8,9,5,7,1,4,3,7,9,5,3,5,8,9,5,7,1,4,3,7,9,5,3]; 
// let obj = {}

// for(let i=0; i<arr.length; i++){
//     if(obj[arr[i]]){
//         obj[arr[i]] += 1
//     }else{
//         obj[arr[i]] = 1
//     }
// }

// console.log(obj)



// remove all zero atlast
// let arr = [1,4,2,0,8,0,0,1];
// let index =0

// for(let i=0;i<arr.length; i++){
//     if(arr[i] !== 0){
//     [arr[index],arr[i]] = [arr[i],arr[index]]
//     index++;
        
//     }
// }
// console.log('arr: ', arr);



// sort
// let arr = [12,43,45,21,36,76,73,23]
// for(let i=0; i<arr.length;){
//     if(arr[i]>arr[i+1]){
//        [arr[i],arr[i+1]] = [arr[i+1],arr[i]]
//        if(i>0){
//            i--
//        }
//     }else{
//         i++
//     }
// }
// console.log(arr)



// two sum and three sum


// let arr = [2,7,11,15]
// let target = 9

// function test(){
// let obj = {}
// for(let i=0; i<arr.length; i++){
//     let temp = target - arr[i]
//     if(obj[temp]){
//         return [arr[i],temp]
//     }
//     else{
//         obj[arr[i]] =  true;
//     }
// }
// }

// console.log(test())




//three sum

// let arr = [2,7,11,15]
// let target = 20

// function test(){
// let obj = {}
// for(let i=0; i<arr.length; i++){
//     let temp = target - arr[i]
//    for(let j=0; j<arr.length; j++){
//     let temp2 = temp - arr[j]
//     if(obj[temp2]){
//         return [arr[i],temp2,arr[j]]
//     }
//     else{
//         obj[arr[i]] =  true;
//     }
// }
// }
// }

// console.log(test())
